import { createContext, memo, useContext, useEffect, useRef, useState } from 'react';
import { Handle, Position } from '@xyflow/react';
import './styles.css';

// Provided by App. Every function returns a Promise that rejects with an Error on failure.
//   sendMessage(threadId, text)
//   forkThread(threadId)
//   pinConstraint(threadId, { key, value?, op?, strength?, scope?, source_message_id? })
//   suggestConstraints(threadId) -> [{ key, value, strength, scope, source_message_id }]
export const CanvasContext = createContext(null);

function RuleChip({ rule, onRevoke }) {
  // Hard rules inherited from a parent thread are locked: only the thread that set them can revoke.
  const locked = rule.inherited && rule.strength === 'hard';
  return (
    <li
      className={`chip ${rule.strength}`}
      title={`${rule.strength} rule${rule.inherited ? ', inherited from a parent thread' : ', set in this thread'}`}
    >
      <span className="chip-key">{rule.key}</span>
      <span className="chip-value">{rule.value}</span>
      {rule.inherited && <span className="chip-tag">{locked ? 'locked' : 'inherited'}</span>}
      {!locked && (
        <button
          type="button"
          className="chip-x nodrag nopan"
          aria-label={`Revoke ${rule.key}`}
          onClick={() => onRevoke(rule)}
        >
          ×
        </button>
      )}
    </li>
  );
}

function ChatThreadNode({ id, data }) {
  const { sendMessage, forkThread, pinConstraint, suggestConstraints } = useContext(CanvasContext);
  const { title, messages } = data;
  const constraints = data.constraints ?? [];

  const [text, setText] = useState('');
  const [inflight, setInflight] = useState(null); // user text awaiting its reply
  const [error, setError] = useState(null);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [ruleKey, setRuleKey] = useState('');
  const [ruleValue, setRuleValue] = useState('');
  const [ruleStrength, setRuleStrength] = useState('hard');
  const [suggestions, setSuggestions] = useState(null); // null = not asked yet
  const [suggesting, setSuggesting] = useState(false);
  const list = useRef(null);
  const busy = inflight !== null;

  // Set scrollTop directly: scrollIntoView can also scroll React Flow's viewport (moving the camera).
  useEffect(() => {
    list.current.scrollTop = list.current.scrollHeight;
  }, [messages.length, inflight]);

  const submit = async () => {
    const value = text.trim();
    if (!value || busy) return;
    setText('');
    setError(null);
    setInflight(value);
    try {
      await sendMessage(id, value);
    } catch (e) {
      setText(value); // give the draft back
      setError(e.message);
    } finally {
      setInflight(null);
    }
  };

  const fork = () => forkThread(id).catch((e) => setError(e.message));

  // Runs an action, surfacing failures (e.g. 409 "locked") in the node instead of throwing.
  const attempt = async (action) => {
    setError(null);
    try {
      await action();
      return true;
    } catch (e) {
      setError(e.message);
      return false;
    }
  };

  const addRule = async () => {
    const key = ruleKey.trim();
    const value = ruleValue.trim();
    if (!key || !value) return;
    const ok = await attempt(() => pinConstraint(id, { key, value, strength: ruleStrength, scope: 'subtree' }));
    if (ok) {
      setRuleKey('');
      setRuleValue('');
    }
  };

  const revoke = (rule) =>
    attempt(() => pinConstraint(id, { key: rule.key, op: 'unset', strength: rule.strength, scope: 'subtree' }));

  const suggest = async () => {
    setSuggesting(true);
    await attempt(async () => setSuggestions(await suggestConstraints(id)));
    setSuggesting(false);
  };

  const pinSuggestion = async (s) => {
    const ok = await attempt(() =>
      pinConstraint(id, {
        key: s.key,
        value: s.value,
        strength: s.strength,
        scope: s.scope,
        source_message_id: s.source_message_id,
      }),
    );
    if (ok) setSuggestions((list) => list.filter((x) => x !== s));
  };

  const onRuleEnter = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addRule();
    }
  };

  return (
    <div className="node thread">
      <Handle type="target" position={Position.Top} isConnectable={false} />

      <header>
        <span className="title" title={title}>{title || 'New thread'}</span>
        <button
          type="button"
          className="nodrag nopan"
          aria-expanded={rulesOpen}
          onClick={() => setRulesOpen((o) => !o)}
        >
          Rules{constraints.length ? ` · ${constraints.length}` : ''}
        </button>
        <button type="button" className="nodrag nopan" onClick={fork} disabled={busy || !messages.length}>
          Fork Thread
        </button>
      </header>

      {rulesOpen && (
        <section className="rules nodrag nopan nowheel" aria-label="Constraints">
          {constraints.length ? (
            <ul className="chips">
              {constraints.map((r) => (
                <RuleChip key={r.id} rule={r} onRevoke={revoke} />
              ))}
            </ul>
          ) : (
            <p className="empty-rules">No rules yet. Rules set here also apply to every fork made from now on.</p>
          )}

          <div className="rule-form">
            <input
              value={ruleKey}
              placeholder="key (database)"
              aria-label="Rule key"
              onChange={(e) => setRuleKey(e.target.value)}
              onKeyDown={onRuleEnter}
            />
            <input
              value={ruleValue}
              placeholder="value (PostgreSQL)"
              aria-label="Rule value"
              onChange={(e) => setRuleValue(e.target.value)}
              onKeyDown={onRuleEnter}
            />
            <select value={ruleStrength} aria-label="Strength" onChange={(e) => setRuleStrength(e.target.value)}>
              <option value="hard">hard</option>
              <option value="soft">soft</option>
            </select>
            <button type="button" onClick={addRule} disabled={!ruleKey.trim() || !ruleValue.trim()}>
              Pin
            </button>
          </div>

          <div className="suggest-row">
            <button type="button" onClick={suggest} disabled={suggesting || !messages.length}>
              {suggesting ? 'Reading…' : 'Suggest rules from chat'}
            </button>
            {suggestions && !suggestions.length && <span className="empty-rules">Nothing new found.</span>}
          </div>
          {suggestions?.length > 0 && (
            <ul className="chips">
              {suggestions.map((s) => (
                <li key={`${s.key}:${s.value}`} className={`chip suggested ${s.strength}`}>
                  <span className="chip-key">{s.key}</span>
                  <span className="chip-value">{s.value}</span>
                  <button type="button" className="nodrag nopan" onClick={() => pinSuggestion(s)}>
                    Pin
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      <div className="messages nodrag nopan nowheel" ref={list}>
        {!messages.length && !busy && <p className="empty">Forked thread. It inherits the parent conversation and its rules — say something.</p>}
        {messages.map((m) => (
          <div key={m.id} className={`msg ${m.role}`}>{m.content}</div>
        ))}
        {busy && (
          <>
            <div className="msg user">{inflight}</div>
            <span className="dots" role="status" aria-label="Waiting for reply"><i /><i /><i /></span>
          </>
        )}
      </div>

      {error && <p className="error" role="alert">{error}</p>}

      <div className="input">
        <textarea
          className="nodrag nopan"
          rows={2}
          value={text}
          disabled={busy}
          placeholder="Continue this thread…"
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
        />
        <button type="button" className="nodrag nopan" onClick={submit} disabled={busy || !text.trim()}>
          Send
        </button>
      </div>

      <Handle type="source" position={Position.Bottom} isConnectable={false} />
    </div>
  );
}

export default memo(ChatThreadNode);
