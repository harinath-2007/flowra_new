import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Background,
  Controls,
  MarkerType,
  Panel,
  ReactFlow,
  ReactFlowProvider,
  useEdgesState,
  useNodesInitialized,
  useNodesState,
  useReactFlow,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import ChatThreadNode, { CanvasContext } from './ChatThreadNode.jsx';
import { layout } from './layout.js';

const nodeTypes = { chatThread: ChatThreadNode };
const edgeOptions = { type: 'smoothstep', markerEnd: { type: MarkerType.ArrowClosed } };

// FastAPI sends `detail` as a string for HTTPException and as a list for validation errors.
function errorText(detail) {
  if (typeof detail === 'string') return detail;
  if (Array.isArray(detail)) return detail.map((d) => d.msg).join('; ');
  return '';
}

async function post(url, body = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const { detail } = await res.json().catch(() => ({}));
    throw new Error(errorText(detail) || res.statusText);
  }
  return res.json();
}

const fmt = (n) => Number(n).toLocaleString();

function NewThread({ onStart }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const submit = async () => {
    const value = text.trim();
    if (!value || busy) return;
    setBusy(true);
    setError(null);
    try {
      await onStart(value);
      setText('');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="composer">
      <textarea
        className="nodrag nowheel nopan"
        rows={3}
        value={text}
        disabled={busy}
        placeholder="Start a new conversation…"
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            submit();
          }
        }}
      />
      {error && <div className="error"><p>{error}</p></div>}
      <button type="button" onClick={submit} disabled={busy || !text.trim()}>
        {busy ? 'Starting…' : 'Start'}
      </button>
    </div>
  );
}

// Prompt tokens actually sent vs. what replaying the full ancestry would have cost (estimated).
function TokenStats({ stats }) {
  if (!stats || !stats.chat_calls) return null;
  const pct = stats.baseline ? Math.round((stats.net_saved / stats.baseline) * 100) : 0;
  return (
    <dl className="token-stats" aria-label="Token usage">
      <dt>Prompt tokens sent</dt>
      <dd>{fmt(stats.sent)}</dd>
      <dt>Full history (est.)</dt>
      <dd>{fmt(stats.baseline)}</dd>
      <dt>Summary + suggest calls</dt>
      <dd>{fmt(stats.overhead)}</dd>
      <dt>Net saved</dt>
      <dd className="net">
        {fmt(stats.net_saved)} ({pct}%)
      </dd>
    </dl>
  );
}

function Canvas() {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [stats, setStats] = useState(null);
  const { fitView } = useReactFlow();
  const initialized = useNodesInitialized();
  const fitted = useRef(false);

  // Refs hold the latest graph so concurrent async completions never merge into stale state.
  const nodesRef = useRef(nodes);
  const edgesRef = useRef(edges);
  nodesRef.current = nodes;
  edgesRef.current = edges;

  // Merge a server response (whole graph + `thread_id` of the thread the request touched).
  //  - The touched thread is overwritten entirely.
  //  - Threads listed in `affected` (descendants of a thread whose rules changed) get only their
  //    `constraints` refreshed, so a slow response can never roll back their messages.
  //  - Everything else keeps its current state, and nothing is ever deleted.
  const commit = useCallback(
    (res, anchorId) => {
      const affected = new Set(res.affected ?? []);
      const byId = new Map(nodesRef.current.map((n) => [n.id, n]));
      for (const n of res.nodes) {
        const prev = byId.get(n.id);
        if (!prev) {
          byId.set(n.id, n);
        } else if (n.id === res.thread_id) {
          byId.set(n.id, { ...prev, ...n, position: prev.position });
        } else if (affected.has(n.id)) {
          byId.set(n.id, { ...prev, data: { ...prev.data, constraints: n.data.constraints } });
        }
      }
      const edgeById = new Map(edgesRef.current.map((e) => [e.id, e]));
      for (const e of res.edges) edgeById.set(e.id, e);

      const nextEdges = [...edgeById.values()];
      const laidOut = layout([...byId.values()], nextEdges, anchorId);
      nodesRef.current = laidOut;
      edgesRef.current = nextEdges;
      setNodes(laidOut);
      setEdges(nextEdges);
      if (res.stats) setStats(res.stats);
    },
    [setNodes, setEdges],
  );

  const sendMessage = useCallback(
    (threadId, content) => post(`/api/threads/${threadId}/messages`, { content }).then((r) => commit(r, threadId)),
    [commit],
  );
  const forkThread = useCallback(
    (parentId) => post('/api/threads', { parent_id: parentId }).then((r) => commit(r, parentId)),
    [commit],
  );
  const startThread = useCallback(
    (content) => post('/api/threads', { content }).then((r) => commit(r, null)),
    [commit],
  );
  // Set or revoke a rule: { key, value?, op?, strength?, scope?, source_message_id? }
  const pinConstraint = useCallback(
    (threadId, rule) => post(`/api/threads/${threadId}/constraints`, rule).then((r) => commit(r, threadId)),
    [commit],
  );
  // Ask the model for candidate rules; resolves to a list, saves nothing.
  const suggestConstraints = useCallback(
    (threadId) => post(`/api/threads/${threadId}/constraints/suggest`).then((r) => r.suggestions),
    [],
  );

  useEffect(() => {
    fetch('/api/graph')
      .then((r) => r.json())
      .then((g) => commit({ ...g, thread_id: null }))
      .catch(console.error);
  }, [commit]);

  // Fit once on first load; later layouts never move the camera.
  useEffect(() => {
    if (initialized && nodes.length && !fitted.current) {
      fitted.current = true;
      fitView({ padding: 0.2, maxZoom: 1 });
    }
  }, [initialized, nodes.length, fitView]);

  const context = useMemo(
    () => ({ sendMessage, forkThread, pinConstraint, suggestConstraints }),
    [sendMessage, forkThread, pinConstraint, suggestConstraints],
  );

  return (
    <CanvasContext.Provider value={context}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        preventScrolling={false}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        defaultEdgeOptions={edgeOptions}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable={false}
        deleteKeyCode={null}
        minZoom={0.1}
        colorMode="system"
        proOptions={{ hideAttribution: true }}
      >
        <Background gap={24} />
        <Controls showInteractive={false} />
        <Panel position="top-left" className="new-chat">
          <NewThread onStart={startThread} />
        </Panel>
        <Panel position="top-right">
          <TokenStats stats={stats} />
        </Panel>
      </ReactFlow>
    </CanvasContext.Provider>
  );
}

export default function App() {
  return (
    <ReactFlowProvider>
      <Canvas />
    </ReactFlowProvider>
  );
}
