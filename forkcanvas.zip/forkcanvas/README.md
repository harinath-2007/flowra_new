# ForkCanvas

Branching AI chat on an infinite canvas. Every thread is a node in a DAG; fork any thread to start an alternative timeline.

## What's new: Constraint Propagation Graph (CPG)

Rules ("database: PostgreSQL") are stored as structured metadata on threads and **travel along the fork edges**. The gateway then builds each prompt from rules + summaries + the newest messages instead of replaying the whole ancestry.

| Concept | Behaviour |
| --- | --- |
| **Inherit** | A fork sees its parent's rules *as they were at the moment of the fork*. Later parent changes never leak in (`fork_msg_rowid` / `fork_con_rowid`). |
| **Override** | A child can set the same key again; the nearest thread, newest entry wins. |
| **Revoke** | Appends an `unset`. Only that subtree loses the rule; forks made earlier keep it. Nothing is ever deleted. |
| **Strength** | `hard`: descendants cannot override or revoke it (HTTP 409). `soft`: a preference, overridable. |
| **Scope** | `subtree` (default) propagates. `local` applies to that thread only. |
| **Provenance** | A rule can carry `source_message_id`, the message it came from. |

### How the prompt is built (`backend/orchestrator.py`)

1. `system`: hard/soft rules in force, then condensed summaries of ancestor threads
2. raw messages not yet covered by a summary (always the newest `KEEP_RAW`)
3. the new user message

Summaries are rolling, per thread, computed in a background task, and **cut at the fork point**, so a fork gets the summary that existed when it was forked. If a summary call fails, the raw tail just stays longer; context is never lost.

`CONTEXT_MODE=full` in `.env` switches back to full-history replay for A/B comparison. The canvas shows prompt tokens actually sent vs. an estimate of full-history cost, net of the summary/suggest calls.

## Run in VS Code

1. `File > Open Folder...` and pick this folder.
2. Add your Groq key: run task **Setup: all** (`Terminal > Run Task...`), then put `GROQ_API_KEY` in `backend/.env`.
3. Run task **Run ForkCanvas** (or `Ctrl/Cmd+Shift+B`). Open http://localhost:5173.
4. Tests: task **Backend: test**, or the Testing sidebar. Debugging: `Run and Debug > Backend (debug)`.

## Run from a terminal

Backend (terminal 1):

    cd backend
    python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env                                # then put your GROQ_API_KEY in it
    uvicorn main:app --reload --env-file .env

Frontend (terminal 2):

    cd frontend
    npm install
    npm run dev                                         # http://localhost:5173 (proxies /api to :8000)

Existing `forkcanvas.db` files upgrade automatically (schema v1 to v2) on startup. Threads created before the upgrade have no fork cutoff, so they keep inheriting their parent's full history.

## API additions

| Endpoint | Purpose |
| --- | --- |
| `POST /api/threads/{id}/constraints` | `{key, value?, op: set/unset, strength, scope, source_message_id?}` |
| `POST /api/threads/{id}/constraints/suggest` | Model proposes rules from recent messages; saves nothing |
| `GET /api/graph` | Nodes now include `data.constraints`; response includes `stats` |
