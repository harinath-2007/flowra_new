"""Gateway-side context orchestration.

Instead of replaying the whole ancestry on every turn, the prompt is assembled from:
  1. the constraints in force for this branch          (Constraint Propagation Graph)
  2. rolling summaries of ancestor threads             (each cut at the fork point)
  3. the raw messages not yet covered by a summary     (always includes the newest few)
  4. the new user message

CONTEXT_MODE=full switches back to full-history replay, for A/B comparison.
"""
import json
import logging
import os
import threading

import db
import llm

log = logging.getLogger("forkcanvas")


def _int(name, default):
    try:
        return max(0, int(os.getenv(name, default)))
    except ValueError:
        return default


def context_mode():
    return "full" if os.getenv("CONTEXT_MODE", "cpg").strip().lower() == "full" else "cpg"


# --------------------------------------------------------------------------- prompt rendering
# Deterministic output (sorted, no timestamps) keeps the prompt prefix stable for provider caching.


def render_rules(rules):
    if not rules:
        return ""
    hard = [r for r in rules if r["strength"] == "hard"]
    soft = [r for r in rules if r["strength"] == "soft"]
    lines = ["PROJECT CONSTRAINTS (inherited by this conversation branch)"]
    if hard:
        lines.append(
            "Hard rules - always obey. If the user asks for something that conflicts with one, "
            "point out the conflict instead of silently breaking it:"
        )
        lines += [f"- {r['key']}: {r['value']}" for r in hard]
    if soft:
        lines.append("Soft preferences - follow unless the user says otherwise:")
        lines += [f"- {r['key']}: {r['value']}" for r in soft]
    return "\n".join(lines)


def render_summaries(levels):
    items = [lv["summary"] for lv in levels if lv["summary"]]
    if not items:
        return ""
    head = "CONDENSED EARLIER CONVERSATION (oldest first; the most recent messages follow verbatim)"
    if len(items) == 1:
        return f"{head}\n{items[0]}"
    return head + "\n" + "\n".join(f"[part {i}] {t}" for i, t in enumerate(items, 1))


def _chars(messages):
    return sum(len(m["content"]) for m in messages)


def build(new_text, thread_id=None, parent_id=None):
    """Assemble the prompt for one turn.

    Pass thread_id for an existing thread, or parent_id for a fork that doesn't exist yet.
    Returns {"messages", "sent_chars", "baseline_chars", "mode"}.
    """
    anchor = thread_id or parent_id
    rules = db.get_effective_constraints(anchor, as_child=thread_id is None)
    rules_text = render_rules(rules)
    user = {"role": "user", "content": new_text}
    mode = context_mode()

    # What full replay would cost - always computed so the saving can be reported honestly.
    full_history = db.get_thread_ancestry(anchor)
    baseline_chars = len(rules_text) + _chars(full_history) + len(new_text)

    if mode == "full":
        history, system_text = full_history, rules_text
    else:
        levels = db.get_context_parts(anchor)
        history = [m for lv in levels for m in lv["messages"]]
        system_text = "\n\n".join(t for t in (rules_text, render_summaries(levels)) if t)

    messages = ([{"role": "system", "content": system_text}] if system_text else []) + history + [user]
    sent_chars = _chars(messages)
    return {
        "messages": messages,
        "sent_chars": sent_chars,
        "baseline_chars": sent_chars if mode == "full" else baseline_chars,
        "mode": mode,
    }


def baseline_tokens(ctx, prompt_tokens):
    """Estimate the full-history prompt size by scaling the real token count by the char ratio."""
    if ctx["mode"] == "full" or not ctx["sent_chars"]:
        return prompt_tokens
    return round(ctx["baseline_chars"] * prompt_tokens / ctx["sent_chars"])


# --------------------------------------------------------------------------- rolling summaries

SUMMARY_SYSTEM = (
    "You maintain a running summary of a conversation so a later assistant can continue it without "
    "the transcript. Keep concrete facts: decisions and their reasons, names, numbers, identifiers, "
    "file/function names, code structure, and unresolved questions. Drop pleasantries and repetition. "
    "Plain prose or short bullets, at most 250 words. Output only the summary."
)

_busy = set()
_busy_lock = threading.Lock()


def maybe_summarize(thread_id):
    """Fold old messages into the thread's rolling summary once enough have piled up.

    Runs as a background task after the response is sent; a failure only means the raw tail
    stays longer for now, never that context is lost.
    """
    with _busy_lock:
        if thread_id in _busy:
            return
        _busy.add(thread_id)
    try:
        if context_mode() == "full":
            return
        work = db.get_summary_work(thread_id, _int("KEEP_RAW", 6), _int("SUMMARY_BATCH", 6))
        if not work:
            return
        previous, rows, upto = work
        transcript = "\n".join(f"{r['role'].upper()}: {r['content'][:4000]}" for r in rows)
        text, pt, ct = llm.chat(
            [
                {"role": "system", "content": SUMMARY_SYSTEM},
                {
                    "role": "user",
                    "content": f"Previous summary:\n{previous or '(none)'}\n\nNew messages:\n{transcript}\n\n"
                    "Write the updated summary.",
                },
            ],
            max_tokens=1500,
        )
        db.save_summary(thread_id, upto, text)
        db.log_call(thread_id, "summary", "cpg", pt, ct)
    except llm.LLMError as e:
        log.warning("summary skipped for %s: %s", thread_id, e.message)
    except Exception:
        log.exception("summary failed for %s", thread_id)
    finally:
        with _busy_lock:
            _busy.discard(thread_id)


# --------------------------------------------------------------------------- constraint suggestions

SUGGEST_SYSTEM = (
    "You extract durable project constraints from a chat. A constraint is a rule the assistant must "
    "keep obeying in later turns: a technology choice, a requirement, a limit, a style rule. Ignore "
    "one-off requests, questions and small talk. Only include constraints the USER stated or clearly "
    "agreed to. Reply with JSON only, no prose:\n"
    '{"constraints":[{"key":"database","value":"PostgreSQL","strength":"hard","source":3}]}\n'
    "key: short snake_case noun. strength: \"hard\" for requirements, \"soft\" for preferences. "
    "source: the [n] index of the message it came from. Return {\"constraints\":[]} if there are none."
)


def suggest_constraints(thread_id):
    """Propose rules from the last few messages. Nothing is saved - the user pins the ones they want."""
    msgs = db.get_recent_messages(thread_id, 8)
    if not msgs:
        return []
    existing = db.get_effective_constraints(thread_id)
    known = "\n".join(f"- {r['key']}: {r['value']}" for r in existing) or "(none)"
    numbered = "\n".join(f"[{i}] {m['role'].upper()}: {m['content'][:1500]}" for i, m in enumerate(msgs))
    text, pt, ct = llm.chat(
        [
            {"role": "system", "content": SUGGEST_SYSTEM},
            {"role": "user", "content": f"Already pinned:\n{known}\n\nMessages:\n{numbered}"},
        ],
        max_tokens=1500,
    )
    db.log_call(thread_id, "suggest", "cpg", pt, ct)
    return _parse_suggestions(text, msgs, existing)


def _parse_suggestions(text, msgs, existing):
    try:
        data = json.loads(text[text.find("{") : text.rfind("}") + 1])
    except ValueError:
        raise llm.LLMError(502, "Could not parse the model's suggestions")
    items = data.get("constraints") if isinstance(data, dict) else None
    known = {(r["key"], (r["value"] or "").lower()) for r in existing}
    out = []
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        key = "_".join(str(item.get("key", "")).lower().split())[:60]
        value = str(item.get("value", "")).strip()[:500]
        if not key or not value or (key, value.lower()) in known:
            continue
        src = item.get("source")
        out.append(
            {
                "key": key,
                "value": value,
                "strength": "soft" if item.get("strength") == "soft" else "hard",
                "scope": "subtree",
                "source_message_id": msgs[src]["id"] if isinstance(src, int) and 0 <= src < len(msgs) else None,
            }
        )
    return out[:5]
