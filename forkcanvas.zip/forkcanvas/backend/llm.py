"""Thin wrapper around the Groq (OpenAI-compatible) API. Reads the environment lazily so it
works no matter when .env is loaded."""
import logging
import os
from functools import lru_cache

import openai

log = logging.getLogger("forkcanvas")
BASE_URL = "https://api.groq.com/openai/v1"


class LLMError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


@lru_cache(maxsize=1)
def _client(api_key):
    return openai.OpenAI(api_key=api_key, base_url=BASE_URL, max_retries=2)


def chat(messages, max_tokens=2048):
    """One LLM turn -> (text, prompt_tokens, completion_tokens). Raises LLMError, never returns junk."""
    key = os.getenv("GROQ_API_KEY")
    if not key:
        raise LLMError(503, "GROQ_API_KEY is not configured")
    model = os.getenv("GROQ_MODEL", "openai/gpt-oss-20b")
    try:
        resp = _client(key).chat.completions.create(
            model=model, messages=messages, max_completion_tokens=max_tokens
        )
    except openai.OpenAIError as e:  # connection, status and timeout errors
        log.exception("LLM call failed")
        raise LLMError(502, f"LLM error: {e}")
    text = (resp.choices[0].message.content or "").strip()
    if not text:  # reasoning models can spend the whole token budget thinking
        raise LLMError(502, "LLM returned an empty reply")
    usage = resp.usage
    return (
        text,
        int(getattr(usage, "prompt_tokens", 0) or 0),
        int(getattr(usage, "completion_tokens", 0) or 0),
    )
