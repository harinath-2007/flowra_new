import logging
import sqlite3
import uuid
from contextlib import asynccontextmanager
from typing import Annotated, Literal

from dotenv import load_dotenv
from fastapi import BackgroundTasks, FastAPI, HTTPException
from pydantic import BaseModel, StringConstraints, model_validator

import db
import llm
import orchestrator

load_dotenv(override=True)  # backend/.env
log = logging.getLogger("forkcanvas")

Text = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=20_000)]
Key = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=60)]
Value = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)]


@asynccontextmanager
async def lifespan(app):
    db.init()
    yield


app = FastAPI(lifespan=lifespan)


class NewThread(BaseModel):
    id: str | None = None
    parent_id: str | None = None
    content: Text | None = None  # omitted -> empty fork, no LLM call


class NewMessage(BaseModel):
    content: Text


class NewConstraint(BaseModel):
    key: Key
    value: Value | None = None
    op: Literal["set", "unset"] = "set"
    strength: Literal["hard", "soft"] = "hard"
    scope: Literal["subtree", "local"] = "subtree"
    source_message_id: str | None = None

    @model_validator(mode="after")
    def _normalize(self):
        self.key = "_".join(self.key.lower().split())
        if self.op == "set" and not self.value:
            raise ValueError("value is required when op is 'set'")
        return self


def graph():
    threads = db.all_threads()
    return {
        "nodes": [
            {
                "id": t["id"],
                "type": "chatThread",
                "position": {"x": 0, "y": 0},
                "data": {
                    "title": t["title"],
                    "parent_id": t["parent_id"],
                    "messages": t["messages"],
                    "constraints": t["constraints"],
                },
            }
            for t in threads
        ],
        "edges": [
            {"id": f'{t["parent_id"]}-{t["id"]}', "source": t["parent_id"], "target": t["id"]}
            for t in threads
            if t["parent_id"]
        ],
        "stats": db.token_stats(),
    }


def run_turn(content, *, log_id, thread_id=None, parent_id=None):
    """One LLM turn through the orchestrator. Raises HTTP 503/502 instead of returning junk."""
    ctx = orchestrator.build(content, thread_id=thread_id, parent_id=parent_id)
    try:
        reply, prompt_tokens, completion_tokens = llm.chat(ctx["messages"])
    except llm.LLMError as e:
        raise HTTPException(e.status, e.message)
    db.log_call(
        log_id, "chat", ctx["mode"], prompt_tokens, completion_tokens, orchestrator.baseline_tokens(ctx, prompt_tokens)
    )
    return reply


# Plain `def` routes: FastAPI runs them in a threadpool, so the blocking SDK and sqlite
# calls never stall the event loop.


@app.get("/api/graph")
def get_graph():
    return graph()


@app.post("/api/threads", status_code=201)
def create_thread(body: NewThread, background: BackgroundTasks):
    if body.parent_id and not db.thread_exists(body.parent_id):
        raise HTTPException(404, "parent thread not found")

    thread_id = body.id or uuid.uuid4().hex
    fork = db.fork_point(body.parent_id)  # captured before the LLM call: the child sees exactly this
    msgs = []
    if body.content:
        # Call the LLM first: nothing is persisted unless the whole turn succeeds.
        reply = run_turn(body.content, log_id=thread_id, parent_id=body.parent_id)
        msgs = [("user", body.content), ("assistant", reply)]

    try:
        db.create_thread(thread_id, body.parent_id, msgs, fork)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "thread id already exists")

    if msgs:
        background.add_task(orchestrator.maybe_summarize, thread_id)
    return {"thread_id": thread_id, "messages": db.get_thread_messages(thread_id), "affected": [], **graph()}


@app.post("/api/threads/{thread_id}/messages", status_code=201)
def post_message(thread_id: str, body: NewMessage, background: BackgroundTasks):
    if not db.thread_exists(thread_id):
        raise HTTPException(404, "thread not found")

    # The user message and the reply are saved together, so a failed LLM call leaves no dangling turn.
    reply = run_turn(body.content, log_id=thread_id, thread_id=thread_id)
    db.add_messages(thread_id, [("user", body.content), ("assistant", reply)])

    background.add_task(orchestrator.maybe_summarize, thread_id)
    return {"thread_id": thread_id, "messages": db.get_thread_messages(thread_id), "affected": [], **graph()}


@app.post("/api/threads/{thread_id}/constraints", status_code=201)
def post_constraint(thread_id: str, body: NewConstraint):
    """Set or revoke a rule on this thread. It propagates to the thread's descendants."""
    if not db.thread_exists(thread_id):
        raise HTTPException(404, "thread not found")
    try:
        db.set_constraint(
            thread_id, body.key, body.value, body.op, body.strength, body.scope, body.source_message_id
        )
    except db.ConstraintLocked as e:
        raise HTTPException(409, str(e))
    except sqlite3.IntegrityError:
        raise HTTPException(400, "unknown source_message_id")
    # `affected` = threads whose effective rules may have changed; the UI refreshes only those.
    return {"thread_id": thread_id, "affected": db.subtree_ids(thread_id), **graph()}


@app.post("/api/threads/{thread_id}/constraints/suggest")
def suggest_constraints(thread_id: str):
    """Ask the model which rules this thread seems to have established. Saves nothing."""
    if not db.thread_exists(thread_id):
        raise HTTPException(404, "thread not found")
    try:
        return {"suggestions": orchestrator.suggest_constraints(thread_id)}
    except llm.LLMError as e:
        raise HTTPException(e.status, e.message)
