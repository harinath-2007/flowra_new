import sqlite3
import uuid
from contextlib import contextmanager

DB_PATH = "forkcanvas.db"
INF = 2**62  # "no cutoff"

# Only run when the old message-level `nodes` table exists. Every user node becomes a thread
# holding itself + its assistant replies; its parent thread is the user node two hops up.
LEGACY_IMPORT = """
INSERT INTO threads (id, parent_id, title, created_at)
SELECT u.id, a.parent_id, substr(u.content, 1, 60), u.timestamp
FROM nodes u LEFT JOIN nodes a ON a.id = u.parent_id
WHERE u.role = 'user' ORDER BY u.rowid;

INSERT INTO messages (id, thread_id, role, content, created_at)
SELECT id, CASE role WHEN 'user' THEN id ELSE parent_id END, role, content, timestamp
FROM nodes ORDER BY rowid;

ALTER TABLE nodes RENAME TO legacy_nodes;
"""

SCHEMA_V1 = """
CREATE TABLE threads (
    id         TEXT PRIMARY KEY,
    parent_id  TEXT REFERENCES threads(id),
    title      TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE messages (
    id         TEXT PRIMARY KEY,
    thread_id  TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    role       TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
    content    TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_threads_parent  ON threads(parent_id);
CREATE INDEX idx_messages_thread ON messages(thread_id);
"""

# V2 = Constraint Propagation Graph.
#  * fork_msg_rowid / fork_con_rowid: "how much of the parent existed when this thread was forked".
#    NULL = no cutoff (root threads, and threads imported from the legacy schema).
#  * constraints: append-only log of rule changes per thread. Nothing is ever deleted; a rule is
#    revoked by appending an `unset`, so threads forked earlier keep the view they were born with.
#  * thread_summaries: rolling summaries of a thread's OWN messages, snapshotted at `upto_rowid`.
#  * llm_calls: token accounting, so the savings can be measured instead of assumed.
SCHEMA_V2 = """
ALTER TABLE threads ADD COLUMN fork_msg_rowid INTEGER;
ALTER TABLE threads ADD COLUMN fork_con_rowid INTEGER;

CREATE TABLE constraints (
    id                TEXT PRIMARY KEY,
    thread_id         TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    key               TEXT NOT NULL,
    value             TEXT,
    op                TEXT NOT NULL DEFAULT 'set'     CHECK (op IN ('set', 'unset')),
    strength          TEXT NOT NULL DEFAULT 'hard'    CHECK (strength IN ('hard', 'soft')),
    scope             TEXT NOT NULL DEFAULT 'subtree' CHECK (scope IN ('subtree', 'local')),
    source_message_id TEXT REFERENCES messages(id) ON DELETE SET NULL,
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_constraints_thread ON constraints(thread_id);

CREATE TABLE thread_summaries (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id  TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    upto_rowid INTEGER NOT NULL,
    text       TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_summaries_thread ON thread_summaries(thread_id, upto_rowid);

CREATE TABLE llm_calls (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id         TEXT,
    kind              TEXT NOT NULL,            -- 'chat' | 'summary' | 'suggest'
    mode              TEXT,                     -- 'cpg' | 'full'
    prompt_tokens     INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    baseline_tokens   INTEGER,                  -- estimated prompt size with full history
    created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


class ConstraintLocked(Exception):
    """A descendant tried to change a hard constraint inherited from an ancestor."""


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        with conn:  # commit on success, rollback on error
            yield conn
    finally:
        conn.close()


def init():
    """Bring the database to the latest schema. Safe to call on every startup."""
    with db() as c:
        c.execute("PRAGMA journal_mode = WAL")  # readers don't block the writer; persists in file
        version = c.execute("PRAGMA user_version").fetchone()[0]
        if version < 1:
            legacy = c.execute("SELECT 1 FROM sqlite_master WHERE name = 'nodes'").fetchone()
            # One explicit transaction: a crash midway leaves user_version at 0 and nothing applied.
            c.executescript(
                "BEGIN;" + SCHEMA_V1 + (LEGACY_IMPORT if legacy else "") + "PRAGMA user_version = 1; COMMIT;"
            )
        if version < 2:
            c.executescript("BEGIN;" + SCHEMA_V2 + "PRAGMA user_version = 2; COMMIT;")


# --------------------------------------------------------------------------- threads & messages


def thread_exists(thread_id):
    with db() as c:
        return c.execute("SELECT 1 FROM threads WHERE id = ?", (thread_id,)).fetchone() is not None


def fork_point(parent_id):
    """(message_rowid, constraint_rowid) = 'now' in the parent's timeline. (None, None) for a root."""
    if not parent_id:
        return (None, None)
    with db() as c:
        m = c.execute("SELECT COALESCE(MAX(rowid), 0) FROM messages WHERE thread_id = ?", (parent_id,)).fetchone()[0]
        k = c.execute("SELECT COALESCE(MAX(rowid), 0) FROM constraints WHERE thread_id = ?", (parent_id,)).fetchone()[0]
    return (m, k)


def _append(c, thread_id, msgs):
    c.executemany(
        "INSERT INTO messages (id, thread_id, role, content) VALUES (?, ?, ?, ?)",
        [(uuid.uuid4().hex, thread_id, role, text) for role, text in msgs],
    )
    c.execute(
        "UPDATE threads SET title = substr(?, 1, 60) WHERE id = ? AND title = ''",
        (msgs[0][1], thread_id),
    )


def create_thread(thread_id, parent_id, msgs=(), fork=(None, None)):
    """Insert a thread and its first (role, content) messages in one transaction.

    `fork` is db.fork_point(parent_id), captured BEFORE the LLM call so the child inherits exactly
    what the model saw, even if the parent moved on while the request was in flight.
    """
    with db() as c:
        c.execute(
            "INSERT INTO threads (id, parent_id, fork_msg_rowid, fork_con_rowid) VALUES (?, ?, ?, ?)",
            (thread_id, parent_id, fork[0], fork[1]),
        )
        if msgs:
            _append(c, thread_id, msgs)


def add_messages(thread_id, msgs):
    """Append (role, content) pairs atomically."""
    with db() as c:
        _append(c, thread_id, msgs)


def get_thread_messages(thread_id):
    with db() as c:
        return [
            dict(r)
            for r in c.execute(
                "SELECT id, role, content, created_at FROM messages WHERE thread_id = ? ORDER BY rowid",
                (thread_id,),
            )
        ]


def get_recent_messages(thread_id, n):
    """The last n messages of this thread only, oldest first, as [{id, role, content}]."""
    with db() as c:
        return [
            dict(r)
            for r in c.execute(
                """SELECT id, role, content FROM
                     (SELECT rowid AS r, id, role, content FROM messages
                      WHERE thread_id = ? ORDER BY rowid DESC LIMIT ?)
                   ORDER BY r""",
                (thread_id, n),
            )
        ]


def subtree_ids(thread_id):
    """thread_id plus every descendant."""
    with db() as c:
        kids = {}
        for r in c.execute("SELECT id, parent_id FROM threads"):
            kids.setdefault(r["parent_id"], []).append(r["id"])
    out, stack = [], [thread_id]
    while stack:
        t = stack.pop()
        out.append(t)
        stack.extend(kids.get(t, []))
    return out


# --------------------------------------------------------------------------- ancestry


def _chain(lookup, thread_id):
    """[(thread_id, msg_cutoff, con_cutoff)] from the thread itself up to the root.

    The cutoffs say how much of that thread is visible to the one below it: a child sees its
    parent only up to the moment it was forked. The starting thread is fully visible (INF).
    """
    out, msg_cut, con_cut, seen = [], INF, INF, set()
    while thread_id and thread_id not in seen:
        row = lookup(thread_id)
        if row is None:
            break
        seen.add(thread_id)
        out.append((thread_id, msg_cut, con_cut))
        msg_cut = INF if row["fork_msg_rowid"] is None else row["fork_msg_rowid"]
        con_cut = INF if row["fork_con_rowid"] is None else row["fork_con_rowid"]
        thread_id = row["parent_id"]
    return out


def _row_lookup(c):
    return lambda tid: c.execute(
        "SELECT parent_id, fork_msg_rowid, fork_con_rowid FROM threads WHERE id = ?", (tid,)
    ).fetchone()


def get_thread_ancestry(thread_id):
    """Full history root ... thread as [{"role", "content"}, ...], honouring fork cutoffs.

    Returns [] for an unknown or None thread_id, so callers can pass a parent_id directly.
    """
    with db() as c:
        out = []
        for tid, cut, _ in reversed(_chain(_row_lookup(c), thread_id)):
            out += [
                dict(r)
                for r in c.execute(
                    "SELECT role, content FROM messages WHERE thread_id = ? AND rowid <= ? ORDER BY rowid",
                    (tid, cut),
                )
            ]
        return out


def get_context_parts(thread_id):
    """Compressed ancestry, root first: [{"thread_id", "summary", "messages"}].

    For each thread on the path: the newest summary that existed at the fork point, plus the raw
    messages after that summary (up to the fork point). Together they replace the full history.
    """
    with db() as c:
        levels = []
        for tid, cut, _ in reversed(_chain(_row_lookup(c), thread_id)):
            snap = c.execute(
                """SELECT upto_rowid, text FROM thread_summaries
                   WHERE thread_id = ? AND upto_rowid <= ?
                   ORDER BY upto_rowid DESC, id DESC LIMIT 1""",
                (tid, cut),
            ).fetchone()
            upto = snap["upto_rowid"] if snap else 0
            tail = [
                dict(r)
                for r in c.execute(
                    """SELECT role, content FROM messages
                       WHERE thread_id = ? AND rowid > ? AND rowid <= ? ORDER BY rowid""",
                    (tid, upto, cut),
                )
            ]
            levels.append({"thread_id": tid, "summary": snap["text"] if snap else None, "messages": tail})
        return levels


# --------------------------------------------------------------------------- summaries


def get_summary_work(thread_id, keep_raw, batch):
    """(previous_summary, rows_to_fold_in, new_upto_rowid) or None when it's not time yet."""
    with db() as c:
        snap = c.execute(
            "SELECT upto_rowid, text FROM thread_summaries WHERE thread_id = ? ORDER BY upto_rowid DESC, id DESC LIMIT 1",
            (thread_id,),
        ).fetchone()
        upto = snap["upto_rowid"] if snap else 0
        rows = [
            dict(r)
            for r in c.execute(
                "SELECT rowid AS rid, role, content FROM messages WHERE thread_id = ? AND rowid > ? ORDER BY rowid",
                (thread_id, upto),
            )
        ]
    if len(rows) < keep_raw + batch:
        return None
    fold = rows[: len(rows) - keep_raw]
    return (snap["text"] if snap else None, fold, fold[-1]["rid"])


def save_summary(thread_id, upto_rowid, text):
    with db() as c:
        c.execute(
            "INSERT INTO thread_summaries (thread_id, upto_rowid, text) VALUES (?, ?, ?)",
            (thread_id, upto_rowid, text),
        )


# --------------------------------------------------------------------------- constraints


def _load_constraints(c):
    """{thread_id: [constraint rows, newest first]}"""
    by_thread = {}
    for r in c.execute(
        """SELECT rowid AS rid, id, thread_id, key, value, op, strength, scope, source_message_id
           FROM constraints ORDER BY rowid DESC"""
    ):
        by_thread.setdefault(r["thread_id"], []).append(dict(r))
    return by_thread


def _winners(chain, by_thread, offset=0):
    """{key: winning row} - the nearest thread wins, and within a thread the newest entry wins.

    `offset` = 1 resolves for a thread that doesn't exist yet and would be a child of chain[0].
    Includes `unset` winners (needed for lock checks); use _effective() for what's in force.
    """
    winners = {}
    for i, (tid, _, cut) in enumerate(chain):
        depth = i + offset
        for r in by_thread.get(tid, ()):
            if r["rid"] > cut:  # created after the fork: this branch never saw it
                continue
            if depth > 0 and r["scope"] == "local":  # local rules don't propagate
                continue
            if r["key"] not in winners:
                winners[r["key"]] = dict(r, inherited=depth > 0)
    return winners


def _effective(chain, by_thread, offset=0):
    return sorted(
        (
            {
                "id": w["id"],
                "key": w["key"],
                "value": w["value"],
                "strength": w["strength"],
                "scope": w["scope"],
                "thread_id": w["thread_id"],
                "inherited": w["inherited"],
                "source_message_id": w["source_message_id"],
            }
            for w in _winners(chain, by_thread, offset).values()
            if w["op"] == "set"
        ),
        key=lambda r: r["key"],
    )


def get_effective_constraints(thread_id, as_child=False):
    """Rules in force for a thread. as_child=True: for a not-yet-created child of thread_id."""
    with db() as c:
        return _effective(_chain(_row_lookup(c), thread_id), _load_constraints(c), 1 if as_child else 0)


def set_constraint(thread_id, key, value, op, strength, scope, source_message_id=None):
    """Append a rule change. Hard rules inherited from an ancestor can't be touched by descendants."""
    with db() as c:
        chain = _chain(_row_lookup(c), thread_id)
        w = _winners(chain, _load_constraints(c)).get(key)
        if w and w["inherited"] and w["op"] == "set" and w["strength"] == "hard":
            raise ConstraintLocked(f"'{key}' is a hard rule inherited from a parent thread and can't be changed here")
        cid = uuid.uuid4().hex
        c.execute(
            """INSERT INTO constraints (id, thread_id, key, value, op, strength, scope, source_message_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (cid, thread_id, key, value if op == "set" else None, op, strength, scope, source_message_id),
        )
        return cid


# --------------------------------------------------------------------------- graph & stats


def all_threads():
    """Every thread, oldest first, each with its ordered `messages` and effective `constraints`."""
    with db() as c:
        rows = c.execute(
            "SELECT id, parent_id, title, created_at, fork_msg_rowid, fork_con_rowid FROM threads ORDER BY rowid"
        ).fetchall()
        by_id = {r["id"]: r for r in rows}
        threads = [
            {k: r[k] for k in ("id", "parent_id", "title", "created_at")} | {"messages": []} for r in rows
        ]
        threads_by_id = {t["id"]: t for t in threads}
        for m in c.execute("SELECT id, thread_id, role, content, created_at FROM messages ORDER BY rowid"):
            threads_by_id[m["thread_id"]]["messages"].append(
                {k: m[k] for k in ("id", "role", "content", "created_at")}
            )
        cons = _load_constraints(c)
        for t in threads:
            t["constraints"] = _effective(_chain(by_id.get, t["id"]), cons)
    return threads


def log_call(thread_id, kind, mode, prompt_tokens, completion_tokens, baseline_tokens=None):
    with db() as c:
        c.execute(
            """INSERT INTO llm_calls (thread_id, kind, mode, prompt_tokens, completion_tokens, baseline_tokens)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (thread_id, kind, mode, prompt_tokens, completion_tokens, baseline_tokens),
        )


def token_stats():
    """Prompt tokens actually sent vs. the estimated full-history cost, net of summary/suggest calls."""
    with db() as c:
        chat = c.execute(
            """SELECT COUNT(*) AS n, COALESCE(SUM(prompt_tokens), 0) AS sent,
                      COALESCE(SUM(baseline_tokens), 0) AS base
               FROM llm_calls WHERE kind = 'chat'"""
        ).fetchone()
        extra = c.execute(
            "SELECT COALESCE(SUM(prompt_tokens + completion_tokens), 0) FROM llm_calls WHERE kind != 'chat'"
        ).fetchone()[0]
    return {
        "chat_calls": chat["n"],
        "sent": chat["sent"],
        "baseline": chat["base"],
        "overhead": extra,
        "net_saved": chat["base"] - chat["sent"] - extra,
    }
