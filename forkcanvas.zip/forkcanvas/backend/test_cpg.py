"""Run:  python -m unittest -v      (from the backend/ folder, venv active)
No API key needed: the LLM is replaced by a fake."""
import json
import os
import tempfile
import unittest

from fastapi.testclient import TestClient

import db
import llm
import main
import orchestrator


class FakeLLM:
    def __init__(self):
        self.calls = []

    def __call__(self, messages, max_tokens=2048):
        self.calls.append(messages)
        sys_text = messages[0]["content"] if messages and messages[0]["role"] == "system" else ""
        if sys_text.startswith("You extract durable"):
            return json.dumps({"constraints": [{"key": "Database", "value": "PostgreSQL", "strength": "hard", "source": 0}]}), 50, 20
        if sys_text.startswith("You maintain a running summary"):
            return "SUMMARY-OF-OLD-MESSAGES", 200, 30
        return "ok reply", sum(len(m["content"]) for m in messages) // 4, 5


class CPGTests(unittest.TestCase):
    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        db.DB_PATH = self.path
        db.init()
        self.fake = FakeLLM()
        self._orig_chat = llm.chat
        llm.chat = self.fake
        os.environ["CONTEXT_MODE"] = "cpg"
        os.environ["KEEP_RAW"] = "2"
        os.environ["SUMMARY_BATCH"] = "2"

    def tearDown(self):
        llm.chat = self._orig_chat
        for suffix in ("", "-wal", "-shm"):
            if os.path.exists(self.path + suffix):
                os.remove(self.path + suffix)

    # helpers
    def thread(self, parent=None, msgs=()):
        tid = os.urandom(4).hex()
        db.create_thread(tid, parent, list(msgs), db.fork_point(parent))
        return tid

    def rules(self, tid):
        return {r["key"]: r["value"] for r in db.get_effective_constraints(tid)}

    # ---- propagation
    def test_child_inherits_and_overrides_soft(self):
        root = self.thread()
        db.set_constraint(root, "language", "Python", "set", "soft", "subtree")
        child = self.thread(root)
        self.assertEqual(self.rules(child), {"language": "Python"})
        db.set_constraint(child, "language", "Go", "set", "soft", "subtree")
        self.assertEqual(self.rules(child), {"language": "Go"})
        self.assertEqual(self.rules(root), {"language": "Python"})  # never leaks upward

    def test_hard_rule_is_locked_for_descendants(self):
        root = self.thread()
        db.set_constraint(root, "database", "PostgreSQL", "set", "hard", "subtree")
        child = self.thread(root)
        with self.assertRaises(db.ConstraintLocked):
            db.set_constraint(child, "database", "SQLite", "set", "hard", "subtree")
        with self.assertRaises(db.ConstraintLocked):
            db.set_constraint(child, "database", None, "unset", "hard", "subtree")

    def test_unset_removes_only_in_subtree(self):
        root = self.thread()
        db.set_constraint(root, "tone", "formal", "set", "soft", "subtree")
        a, b = self.thread(root), self.thread(root)
        db.set_constraint(a, "tone", None, "unset", "soft", "subtree")
        self.assertEqual(self.rules(a), {})
        self.assertEqual(self.rules(b), {"tone": "formal"})
        self.assertEqual(self.rules(root), {"tone": "formal"})

    def test_local_scope_does_not_propagate(self):
        root = self.thread()
        db.set_constraint(root, "scratch", "only here", "set", "soft", "local")
        self.assertEqual(self.rules(root), {"scratch": "only here"})
        self.assertEqual(self.rules(self.thread(root)), {})

    def test_fork_cutoff_hides_later_parent_changes(self):
        root = self.thread(msgs=[("user", "hi"), ("assistant", "hello")])
        db.set_constraint(root, "database", "PostgreSQL", "set", "hard", "subtree")
        early = self.thread(root)
        db.set_constraint(root, "auth", "OAuth", "set", "hard", "subtree")
        db.add_messages(root, [("user", "later"), ("assistant", "later reply")])
        late = self.thread(root)
        self.assertEqual(self.rules(early), {"database": "PostgreSQL"})
        self.assertEqual(self.rules(late), {"database": "PostgreSQL", "auth": "OAuth"})
        self.assertEqual([m["content"] for m in db.get_thread_ancestry(early)], ["hi", "hello"])
        self.assertEqual(len(db.get_thread_ancestry(late)), 4)

    def test_revoking_in_parent_does_not_rewrite_earlier_forks(self):
        root = self.thread()
        db.set_constraint(root, "tone", "formal", "set", "soft", "subtree")
        early = self.thread(root)
        db.set_constraint(root, "tone", None, "unset", "soft", "subtree")
        self.assertEqual(self.rules(root), {})
        self.assertEqual(self.rules(early), {"tone": "formal"})

    def test_grandchild_walks_two_levels(self):
        root = self.thread()
        db.set_constraint(root, "database", "PostgreSQL", "set", "hard", "subtree")
        mid = self.thread(root)
        db.set_constraint(mid, "cache", "Redis", "set", "soft", "subtree")
        leaf = self.thread(mid)
        self.assertEqual(self.rules(leaf), {"database": "PostgreSQL", "cache": "Redis"})
        self.assertTrue(all(r["inherited"] for r in db.get_effective_constraints(leaf)))

    # ---- context building
    def test_prompt_contains_rules_and_new_message(self):
        root = self.thread(msgs=[("user", "plan an api"), ("assistant", "sure")])
        db.set_constraint(root, "database", "PostgreSQL", "set", "hard", "subtree")
        ctx = orchestrator.build("next question", parent_id=root)  # fork that doesn't exist yet
        self.assertEqual(ctx["messages"][0]["role"], "system")
        self.assertIn("database: PostgreSQL", ctx["messages"][0]["content"])
        self.assertEqual(ctx["messages"][-1], {"role": "user", "content": "next question"})

    def test_summary_replaces_old_messages(self):
        tid = self.thread()
        for i in range(4):  # 8 messages, KEEP_RAW=2 + BATCH=2 -> summarize
            db.add_messages(tid, [("user", f"question {i} " + "x" * 400), ("assistant", f"answer {i} " + "y" * 400)])
        orchestrator.maybe_summarize(tid)
        ctx = orchestrator.build("and now?", thread_id=tid)
        text = "\n".join(m["content"] for m in ctx["messages"])
        self.assertIn("SUMMARY-OF-OLD-MESSAGES", text)
        self.assertNotIn("question 0", text)  # folded away
        self.assertIn("answer 3", text)  # newest kept verbatim
        self.assertLess(ctx["sent_chars"], ctx["baseline_chars"])

    def test_fork_uses_summary_that_existed_at_fork_time(self):
        tid = self.thread()
        for i in range(4):
            db.add_messages(tid, [("user", f"q{i}"), ("assistant", f"a{i}")])
        orchestrator.maybe_summarize(tid)
        child = self.thread(tid)
        db.add_messages(tid, [("user", "after fork"), ("assistant", "after fork reply")])
        text = "\n".join(m["content"] for m in orchestrator.build("hey", thread_id=child)["messages"])
        self.assertNotIn("after fork", text)
        self.assertIn("SUMMARY-OF-OLD-MESSAGES", text)

    def test_full_mode_replays_everything(self):
        os.environ["CONTEXT_MODE"] = "full"
        tid = self.thread(msgs=[("user", "one"), ("assistant", "two")])
        ctx = orchestrator.build("three", thread_id=tid)
        self.assertEqual([m["content"] for m in ctx["messages"]], ["one", "two", "three"])
        self.assertEqual(ctx["sent_chars"], ctx["baseline_chars"])

    # ---- HTTP API
    def test_api_flow(self):
        with TestClient(main.app) as client:
            r = client.post("/api/threads", json={"content": "Build me an API"})
            self.assertEqual(r.status_code, 201)
            root = r.json()["thread_id"]

            r = client.post(f"/api/threads/{root}/constraints", json={"key": "Database ", "value": "PostgreSQL"})
            self.assertEqual(r.status_code, 201)
            self.assertIn(root, r.json()["affected"])

            child = client.post("/api/threads", json={"parent_id": root}).json()["thread_id"]
            nodes = {n["id"]: n for n in client.get("/api/graph").json()["nodes"]}
            self.assertEqual(nodes[child]["data"]["constraints"][0]["key"], "database")
            self.assertTrue(nodes[child]["data"]["constraints"][0]["inherited"])

            r = client.post(f"/api/threads/{child}/constraints", json={"key": "database", "value": "SQLite"})
            self.assertEqual(r.status_code, 409)
            r = client.post(f"/api/threads/{root}/constraints", json={"key": "x"})
            self.assertEqual(r.status_code, 422)  # value required for 'set'

            r = client.post(f"/api/threads/{child}/messages", json={"content": "hello"})
            self.assertEqual(r.status_code, 201)
            self.assertTrue(any("database: PostgreSQL" in m["content"] for m in self.fake.calls[-1] if m["role"] == "system"))
            self.assertEqual(r.json()["stats"]["chat_calls"], 2)

            # already inherited -> not suggested again
            r = client.post(f"/api/threads/{child}/constraints/suggest")
            self.assertEqual(r.json()["suggestions"], [])
            # a thread without the rule gets it suggested, key normalized, provenance attached
            fresh = client.post("/api/threads", json={"content": "use postgres"}).json()["thread_id"]
            s = client.post(f"/api/threads/{fresh}/constraints/suggest").json()["suggestions"][0]
            self.assertEqual((s["key"], s["value"]), ("database", "PostgreSQL"))
            self.assertIsNotNone(s["source_message_id"])


if __name__ == "__main__":
    unittest.main()
